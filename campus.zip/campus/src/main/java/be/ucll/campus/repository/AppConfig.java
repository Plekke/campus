package be.ucll.campus.repository;

import org.springframework.context.annotation.Bean;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class AppConfig {
    @Bean
    public EntityManager entityManager(){
        return Persistence
                .createEntityManagerFactory("campus")
                .createEntityManager();
    }
}
